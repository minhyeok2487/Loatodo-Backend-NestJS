import { Controller, Get, Query } from '@nestjs/common';
import { CommentsService } from './comments.service';
import { ResponseCommentDto } from './dto/response-comment.dto';
import { PagingDto } from 'src/paging.dto';

@Controller('comments')
export class CommentsController {
  constructor(private readonly commentsService: CommentsService) {}

  @Get()
  findAll(
    @Query('page') page: number = 1,
  ): Promise<PagingDto<ResponseCommentDto[]>> {
    return this.commentsService.findAll(page);
  }
}
