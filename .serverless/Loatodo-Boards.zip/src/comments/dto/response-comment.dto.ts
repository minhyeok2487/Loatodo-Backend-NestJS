import { Role } from 'src/member/entities/member.entity';
import { Comments } from '../entities/comments.entity';

export class ResponseCommentDto {
  id: number;
  body: string;
  parentId: number;
  memberId: number;
  username: string;
  role: Role;
  regDate: Date;

  static createResponseDto(comment: Comments): ResponseCommentDto {
    const responseDto = new ResponseCommentDto();
    responseDto.id = comment.id;
    responseDto.body = comment.body;
    responseDto.parentId = comment.parentId;
    responseDto.memberId = comment.member.id;
    responseDto.username = comment.member.username;
    responseDto.role = comment.member.role;
    responseDto.regDate = comment.createdDate;

    return responseDto;
  }
}
