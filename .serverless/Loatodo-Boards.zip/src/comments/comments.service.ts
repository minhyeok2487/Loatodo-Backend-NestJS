import { Injectable } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { Comments } from './entities/comments.entity';
import { Repository } from 'typeorm';
import { ResponseCommentDto } from './dto/response-comment.dto';
import { PagingDto } from 'src/paging.dto';

@Injectable()
export class CommentsService {
  constructor(
    @InjectRepository(Comments)
    private readonly commentsRepository: Repository<Comments>,
  ) {}

  // 전체 댓글과 답글을 가져오는 메서드
  async findAll(
    page: number,
    size: number = 5,
  ): Promise<PagingDto<ResponseCommentDto[]>> {
    const parentComments: Comments[] = await this.getCommentsByParentId(
      0,
      page,
      size,
    );

    const totalPages: number = await this.commentsRepository.count();

    // 각 부모 댓글에 대한 답글도 함께 가져옴
    const allComments: ResponseCommentDto[][] = await Promise.all(
      parentComments.map(
        async (comment: Comments): Promise<ResponseCommentDto[]> => {
          const replies: Comments[] = await this.getCommentsByParentId(
            comment.id,
          );
          const commentDtos: ResponseCommentDto[] = [
            ResponseCommentDto.createResponseDto(comment),
          ];
          const replyDtos: ResponseCommentDto[] = replies.map(
            (reply: Comments) => ResponseCommentDto.createResponseDto(reply),
          );
          return [...commentDtos, ...replyDtos];
        },
      ),
    );

    const result: PagingDto<ResponseCommentDto[]> = new PagingDto();
    result.data = allComments.flat();
    result.totalPages = totalPages;
    return result;
  }

  // 부모 ID로 댓글을 가져오는 함수 (페이지네이션 가능)
  private async getCommentsByParentId(
    parentId: number,
    page?: number,
    size?: number,
  ): Promise<Comments[]> {
    const query = this.commentsRepository
      .createQueryBuilder('comments')
      .leftJoinAndSelect('comments.member', 'member')
      .where('comments.parentId = :parentId', { parentId })
      .orderBy('comments.id', 'DESC');

    // 페이지네이션 처리
    if (page !== undefined && size !== undefined) {
      query.skip((page - 1) * size).take(size);
    }

    return await query.getMany();
  }
}
