export class PagingDto<T> {
  data: T;
  totalPages: number;
}
